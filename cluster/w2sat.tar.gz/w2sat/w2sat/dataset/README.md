# dataset description

The formulas is the instances from SATLib and SAT competition.
The benchmark-1 is the instances generate by our framework.