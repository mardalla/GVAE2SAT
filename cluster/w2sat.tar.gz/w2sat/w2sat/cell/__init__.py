"""Implementation of the Cross-Entropy Low-rank Logits (CELL) algorithm."""
