from argparse import ArgumentParser
import pandas as pd
import os

def main():
    parser = ArgumentParser()
    parser.add_argument("--dest", dest="dest", type=str,
                        default="dataset/lcg_stats.csv",
                        help="where to save csv")
    parser.add_argument("--src", dest="src", nargs='+',
                        default=["/home/dcrowley/cnfs/cnfs_test"],
                        help="paths to directories of CNFs")
    args = parser.parse_args()

    stats = []

    for path in args.src:
        for problem in os.listdir(path):
            with open(os.path.join(path, problem), "r") as file:
                sym = 'c'
                while sym != 'p':
                    line = file.readline()
                    sym = line[0]
            stats.append([problem] + [int(x) for x in line.split()[2:4]])

    pd.DataFrame(stats).to_csv(args.dest,
                               header=False, index=False)
    

if __name__ == "__main__":
    main()
