import os
import time
import subprocess

def main():
    
    time0 = time.time()
    for repeat in range(10):
        subprocess.call(["python", "main_test.py",
                         "--data_name", "test_set",
                         "--epoch_load", "150",
                         "--repeat", f"{repeat}"])
    time_gen = time.time() - time0

    
    with open("new_time.txt", "w") as file:
        file.writelines([
            f"Generation: {time_gen}\n"])

    time0 = time.time()
    for repeat in range(10):
        graph_path = f"graphs/test_set_SAGE_3_32_preTrue_dropFalse_yield1_0_150_{repeat}"
        for dat in os.listdir(graph_path):
            eval_conv = ["python", "eval/conversion.py",
                         "--src", os.path.join(graph_path, dat),
                         "--store-dir", "formulas/",
                         "--repeat", f"{repeat}"]
            eval_conv += ["--action=lcg2sat"]

            subprocess.call(eval_conv)

    time_post = time.time() - time0
    with open("new_time.txt", "a") as file:
        file.writelines([
            f"Postprocessing: {time_post}\n"])

if __name__ == "__main__":
    main()
