from argparse import ArgumentParser
import functools
import os

def main():
    parser = ArgumentParser()
    parser.add_argument("--path", dest="path")
    args = parser.parse_args()

    files = [f for f in os.listdir() if f.endswith("cnf")]

    for file in files:
        print(file)
        with open(file, "r") as f:
            lines = f.readlines()
        for idx, line in enumerate(lines):
            if line[0] == 'p':
                header_num = idx
        num_clauses = len(lines) - header_num - 1
        clauses = [l.split() for l in lines[header_num+1:]]
        variables = functools.reduce(lambda x, y: x+y, clauses)
        variables = [abs(int(v)) for v in variables]
        num_vars = max(variables)
        header = f"p cnf {num_vars} {num_clauses}\n"
        lines[header_num] = header
        with open(file, "w") as f:
            f.writelines(lines)
    
if __name__ == "__main__":
    main()
